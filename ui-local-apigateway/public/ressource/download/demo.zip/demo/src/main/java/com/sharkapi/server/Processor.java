package com.sharkapi.server;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * 数据处理器模板代码，必须是当前类 com.sharkapi.server.Processor
 * 方法名 method必须是 invoke
 * injson格式为入参或结果数据，如果多数据项结果即会传入多节点
 * @author shark
 */
public class Processor {

    public static JSONObject invoke(JSONObject injson) throws Exception{
    	if( injson==null) return injson;
    	//须对入参克隆一次，否则下面直接修改入参数据不生效
    	JSONObject json = JSONObject.parseObject( injson.toJSONString());
    	
        System.out.println("处理前输入数据: "+json.toJSONString());
        try{
        	for( String nodeName: json.keySet()){
                //实际中不用分入参或结果处理，直接针对入参和结果处理分别写处理器即可
                if( json.get( nodeName) instanceof JSONObject) {
                	//是对象，进行结果处理
                	//示例：对输入数据每行的最后一个数据加上"_byresult"内容
                    System.out.println("+结果处理节点: "+nodeName);
            		JSONObject item = json.getJSONObject( nodeName);
            		if( item.get( "data") instanceof JSONArray) {
	            		JSONArray data = item.getJSONArray( "data");
	            		for( int n=0; n<data.size(); n++) {
	            			JSONArray line = data.getJSONArray( n);
	            			int len = line.size();
	                        System.out.println("++结果处理数据行: "+String.valueOf( n+1)+"，列数:"+String.valueOf( len));
	            			if( len>0) {
	            				line.set( len-1, line.getString( len-1)+"_byresult");
	            			}
	            		}
            		}
                }else{
                	//非对象，进行入参处理
                	//示例：对输入数据转为字串并加上"_byparam"内容
                    System.out.println("+入参处理节点: "+nodeName);
                	json.put( nodeName, json.getString( nodeName)+"_byparam");
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        System.out.println("处理后输出数据: "+json.toJSONString());
        return json;
    }
}
