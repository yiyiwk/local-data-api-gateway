package com.api.server;

import com.alibaba.fastjson.JSONObject;

/* 数据处理必须是当前类 com.api.server.analysis
* 方法名 method必须是 invoke
* */
public class analysis {

    public static JSONObject invoke(JSONObject json) throws Exception{

        System.out.println("jar包中的输出--"+json.toJSONString());
        try{

            JSONObject result = new JSONObject();
            result.put("a","111");
            result.put("b","222");
            result.put("c","333");
            result.put("d","444");
            result.put("mobile","654321");
            return result;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) throws Exception{
        JSONObject json = new JSONObject();
        json.put("mobile","7a4dfa20186f96d134f00a038ea6e929");
        json.put("aa","111");

        System.out.println(invoke(json));
    }
}
