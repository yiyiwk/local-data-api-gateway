# 处理器模板工程说明：

# 1、本地网关下载模板工程，解压
# 2、首先阅读工程demo/目录下readme.md
# 3、模板工程技术 maven+jdk11
# 4、工程默认依赖包 fastjson、hutool工具包
# 4、处理器代码编写类必须是com.api.server.analysis
# 5、处理器编写方法必须是invoke
# 6、编写完，使用maven打包jar包，最后网关上传处理器
